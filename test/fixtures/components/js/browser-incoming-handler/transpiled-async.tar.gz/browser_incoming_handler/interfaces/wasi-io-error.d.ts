export namespace WasiIoError {
  export { Error };
}

export class Error {
  toDebugString(): string;
}
