export namespace WasiRandomRandom {
  export function getRandomBytes(len: bigint): Uint8Array;
  export function getRandomU64(): bigint;
}
