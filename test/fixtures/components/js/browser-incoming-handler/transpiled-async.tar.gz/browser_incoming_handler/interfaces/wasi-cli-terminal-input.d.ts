export namespace WasiCliTerminalInput {
  export { TerminalInput };
}

export class TerminalInput {
}
