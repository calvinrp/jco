export namespace WasiCliTerminalStdout {
  export function getTerminalStdout(): TerminalOutput | undefined;
}
import type { TerminalOutput } from './wasi-cli-terminal-output.js';
export { TerminalOutput };
